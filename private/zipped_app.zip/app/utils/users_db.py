users = [
        {"username": "supreme_user", "password": "af351f443130f369c0cde982110a07bb8f88112ccfb0b9236eac1e2a23cb0541", "role": 0},
        {"username": "admin", "password": "2ae3a0f2ef89bf388e7cdc7f5fc9f1b60e5542d0a6c2f6f1cf88190d0ab2b711", "role": 1}
]
