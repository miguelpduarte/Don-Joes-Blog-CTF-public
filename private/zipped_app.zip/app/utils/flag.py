flag = 'flag{the_real_flag_is_on_the_server}'
